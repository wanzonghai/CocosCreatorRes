'use strict';

const path = require('path');
const PinyinMatch = require('pinyin-match');

const utils = Editor.require('packages://cocos-services/panel/utils/utils.js');

/**
 * 检测输入的搜索关键字是否像ID
 */
function isIdLikeKeyword(text) {
  // 如果输入的关键字全部是数字（没有任何其他东西），那么就是。
  return text.match(/^\d+$/);
}

const DropdownSearchBox = Vue.extend({
  template: fs.readFileSync(
    path.join(__dirname, 'DropdownSearchBox.html'),
    'utf-8'
  ),
  props: ['items', 'itemIds', 'setSearchResult', 'initialInput'],
  data() {
    return {
      inputText: this.initialInput
    };
  },
  compiled() {
    this.$watch('inputText', () => {
      this.updateClearBtnAppearance();
    });
    this.updateClearBtnAppearance();
  },
  computed: {
    matchedContents() {
      let matchedResult = this.items.map((item, index) => {
        const keyword = this.inputText;
        let matched = false;
        if (isIdLikeKeyword(keyword)) {
          matched = this.itemIds[index].includes(keyword);
        } 
        // 如果通过id搜索成功了，那么直接返回，否则继续尝试按item字符串进行匹配。
        if (matched) {
          return {
            text: item,
            id: this.itemIds[index]
          };
        }
        const keywords = keyword.split(/\s+/);
        if (keywords.every((keyword) => PinyinMatch.match(item, keyword))) {
          return {
            text: item,
            id: this.itemIds[index]
          };
        } else {
          return {
            text: ''
          };
        }
      });
      matchedResult = matchedResult.filter(item => item.text);
      if (!matchedResult.length) {
        // 如果因为没有一个匹配结果，下拉搜索框消失，那么不会触发leader消息，这里需要手动赋值为false。
        this.dropdownContentHovering = false;
      }
      return matchedResult
    },
  },
  methods: {
    utils_t(key, ...args) {
      return utils.t(key, ...args);
    },
    onInputFocus() {
      if (!this.isSearching) {
        this.startSearching();
      }
    },
    onInputBlur() {
      if (
        this.wantForceBlur ||
        (!this.clearBtnHovering && !this.dropdownContentHovering)
      ) {
        this.wantForceBlur = false;
        this.stopSearching();
      }
    },
    onInputEscPressed() {
      this.forceBlur();
    },
    onInputEnterPressed() {
      this.forceBlur();
    },
    onClearBtnMouseOver() {
      this.clearBtnHovering = true;
    },
    onClearBtnMouseLeave() {
      this.clearBtnHovering = false;
    },
    onClearBtnClick() {
      this.inputText = '';
      if (this.isSearching) {
        this.$els.searchInput.focus();
      } else {
        this.setSearchResult('');
      }
    },
    onDropdownContentMouseOver() {
      this.dropdownContentHovering = true;
    },
    onDropdownContentMouseLeave() {
      this.dropdownContentHovering = false;
      if (this.isSearching) {
        this.$els.searchInput.focus();
      }
    },
    onItemMouseOver() {
      this.$els.searchInput.focus();
    },
    onItemClick(e) {
      const text = e.target.textContent;
      this.inputText = text;
      this.stopSearching();
    },
    startSearching() {
      this.isSearching = true;
      this.$els.dropdownContent.classList.remove('analytics-dropdown-hide');
    },
    stopSearching() {
      this.isSearching = false;
      this.setSearchResult(this.inputText);
      this.$els.dropdownContent.classList.add('analytics-dropdown-hide');
    },
    forceBlur() {
      this.wantForceBlur = true;
      this.$els.searchInput.blur();
    },
    updateClearBtnAppearance() {
      if (this.inputText === '') {
        this.$els.clearBtn.classList.add('analytics-dropdown-hide');
      } else {
        this.$els.clearBtn.classList.remove('analytics-dropdown-hide');
      }
    },
  },
});

module.exports = DropdownSearchBox;

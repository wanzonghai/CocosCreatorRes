"use strict";
let fs = require("fs");
let path = require("path");
let { shell } = require("electron");
const { sanitizeUserParam } = require(path.join(__dirname, "../lib/sanitize"));
let utils = Editor.require("packages://cocos-services/panel/utils/utils.js");
let projectPath = Editor.Project && Editor.Project.path ? Editor.Project.path : Editor.projectInfo.path;
let getGameData = function () {
  var devmode = false;
  var data = utils.readJson(`${Editor.remote.App.home}/local/service.json`);
  if ((typeof data.devmode) !== 'undefined') devmode = data.devmode;
  var configPath = projectPath + "/settings/services.json";
  if (devmode && fs.existsSync(projectPath + "/settings/dev-services.json"))
    configPath = projectPath + "/settings/dev-services.json";
  var data = utils.readJson(configPath);
  return data.game ? data.game : {
    appid: '0'
  };
};

let DropdownSearchBox = require(path.join(__dirname, "components/DropdownSearchBox/DropdownSearchBox"));

function matchPrefixIgnoreCase(str, prefix) {
  return str.toLowerCase().startsWith(prefix.toLowerCase());
}

function platformToString(platform) {
  switch (platform) {
    case "1":
      // Android
      return "Android";
    case "2":
      // iOS
      return "iOS";
    case "5":
      // H5
      return "H5";
    default:
      return "";
  }
}

function getStoreDisplayName(store) {
  const prefix = platformToString(store.platform);
  if (!matchPrefixIgnoreCase(store.c_name, prefix)) {
      // 如果没有前缀，加上前缀
    return prefix + "-" + store.c_name;
  }
  return store.c_name;
}

var analyticsVue = Vue.extend({
  components: {
    "dropdown-search-box": DropdownSearchBox
  },
  template: fs.readFileSync(path.join(__dirname, "index.html"), "utf-8"),
  props: {
    params: {
      type: Object
    }
  },
  data() {
    return {
      appid: "",
      stores: null,
      store_id: "",
      store_id_platform: "",
      enableButton: true,
      sty: {
        display: "none",
        position: "absolute",
        top: "0",
        left: "20px",
        "box-shadow": "0px 8px 16px 0px rgba(0,0,0,2)",
        padding: "12px, 16px",
        "max-width": "250px"
      },
      tipText: ""
    };
  },
  computed: {
    storeTexts() {
      return this.stores.map(getStoreDisplayName);
    },
    storeIds() {
      return this.stores.map(store => store.c_id);
    },
    selectedStoreText() {
      if (!this.store_id) {
        return "";
      }
      const selectedStore = this.stores.find(
        (store) => store.c_id === this.store_id
      );
      if (!selectedStore) {
        // 用户可能自行输入渠道大全没有的渠道，此时store_id就是用户自行输入的渠道，直接返回它。
        return this.store_id;
      }
      return getStoreDisplayName(selectedStore);
    }
  },
  created() {
    if (this.params) {
      this.appid = getGameData().appid;
      this.store_id = this.params.store_id ? this.params.store_id : "";
      this.store_id_platform = this.params.store_id_platform ? this.params.store_id_platform : "";
      var porjectPath = Editor.remote.Project ? Editor.remote.Project.path : Editor.remote.projectInfo.path;
      var tmpFilePath = `${porjectPath}/temp/analyticsTmp`;
      if (!fs.existsSync(tmpFilePath)) {
        fs.writeFileSync(tmpFilePath, '0');
        this.handleSaveParamsLogic(false);
        // 重新设置参数并加载预览插件
        this.handleReloadPlugin();
      } else {
        this.checkMissingParams();
      }
    } else {
      this.checkMissingParams();
    }
    this.fetchStores();
  },
  methods: {
    utils_t: function (key, ...args) {
      return utils.t(key, ...args);
    },
    checkMissingParams() {
      if (!this.appid) {
        utils.printToCreatorConsole("warn", this.utils_t("analytics.missing_params_tips"));
      }
    },
    handleSaveParamsLogic: function(needReloadPlugin = true) {
      this.checkMissingParams();
      var params = {};
      params.appid = this.appid;
      params.store_id = this.store_id;
      params.store_id_platform = this.store_id_platform;
      this.$emit("save-param", params);
      if (needReloadPlugin) {
        this.reloadPlugin();
        // 此处设置为 true 是为了避免修改完渠道之后没有成功同步到预览插件，
        // 用户可以手动点击重新加载预览插件按钮来重新同步。
        this.enableButton = true;
      }
    },
    maintainChannel() {
      // 网站关闭
      shell.openExternal("http://dq.qudao.info/service/store");
    },
    handleReloadPlugin: function () {
      // 禁用按钮，5秒后再启用
      if (!this.enableButton) return;
      this.enableButton = false;
      setTimeout(() => this.enableButton = true, 5000);
      this.reloadPlugin();
      utils.printToCreatorConsole("info", this.utils_t("analytics.preview_tips"));
    },
    reloadPlugin() {
      let filePath = path.join(__dirname, "../resources/cocos-analytics-preview-script/main.js");
      this.replaceCodeSegment(filePath, /appid = '.*'/, `appid = '${sanitizeUserParam(this.appid)}'`);
      this.replaceCodeSegment(filePath, /store = '.*'/, `store = '${sanitizeUserParam(this.store_id)}'`);
      try {
        utils.removeDir(`${projectPath}/packages/cocos-analytics-preview-script`);
        utils.copyDir(`${__dirname}/../resources/cocos-analytics-preview-script`, `${projectPath}/packages/cocos-analytics-preview-script`);
      } catch (error) {
        try {
          utils.removeDir(`${projectPath}/packages/cocos-analytics-preview-script`);
          utils.copyDir(`${__dirname}/../resources/cocos-analytics-preview-script`, `${projectPath}/packages/cocos-analytics-preview-script`);
        } catch (error) {
          try {
            utils.removeDir(`${projectPath}/packages/cocos-analytics-preview-script`);
            utils.copyDir(`${__dirname}/../resources/cocos-analytics-preview-script`, `${projectPath}/packages/cocos-analytics-preview-script`);
          } catch (error) {
            utils.printToCreatorConsole("warn", "Operation not permission");
          }
        }
      }
    },
    replaceCodeSegment: function (filePath, match, code) {
      if (!fs.existsSync(filePath)) return;
      let content = fs.readFileSync(filePath, "utf8");
      content = content.replace(match, code);
      utils.printLog(`replace code "${code} to "${filePath}" with regular "${match}"`);
      fs.writeFileSync(filePath, content);
    },
    getRealPath: function (virPath) {
      return __dirname + "/res/" + virPath;
    },
    enter: function (e) {
      const boundingParentRect = this.$els.analyticsContainer.getBoundingClientRect();
      const boundingRect = e.target.getBoundingClientRect();
      this.sty.top = boundingRect.top - boundingParentRect.top + 10;
      this.sty.left = boundingRect.left - boundingParentRect.left;
      switch (e.target.id) {
        case "analytics-appid-label":
          this.tipText = this.utils_t("analytics.appid_tips");
          break;
        case "analytics-store-label":
          this.tipText = this.utils_t("analytics.store_tips");
          break;
      }
      if (this.sty.display === "none") this.sty.display = "block";
    },
    leave: function () {
      this.sty.display = "none";
    },
    fetchStores() {
      fetch("https://creator-api.cocos.com/api/service/get_channel_lists", {
        method: "POST"
      })
      .then(response => response.json())
      .then(json => {
        this.stores = json.data.sort(
          (store1, store2) =>
            getStoreDisplayName(store1).localeCompare(getStoreDisplayName(store2))
        );
      });
    },
    setSearchResult(storeText) {
      const selectedStore = this.stores.find(
        (store) => getStoreDisplayName(store) === storeText
      );

      if (selectedStore) {
        this.store_id = selectedStore.c_id;
        this.store_id_platform = platformToString(selectedStore.platform);
      } else {
        this.store_id = storeText;
        this.store_id_platform = "";
      }
      this.handleSaveParamsLogic();
    },
  }
});
Vue.component("service-analytics", analyticsVue);

"use strict";
const path = require("fire-path");
const fs = require("fire-fs");
const crypto = require("crypto");
const i18nEn = require("./pages/i18n/en");
const i18nZh = require("./pages/i18n/zh");
const { sanitizeUserParam } = require("./lib/sanitize");
const { SSL_OP_NETSCAPE_REUSE_CIPHER_CHANGE_BUG } = require("constants");
let utils = Editor.require("packages://cocos-services/panel/utils/utils.js");
let ccServices = Editor.require("packages://cocos-services/panel/utils/ccServices.js");
let ProjHelper = Editor.require("packages://cocos-services/panel/utils/projHelper.js");
var projHelper;

var analyticsFileName = "cocosAnalytics.min.3.0.2.js";

const generalStoreIdMap = {
  'android': 'Android',
  'ios': 'iOS',
  'web-mobile': 'H5',
  'web-desktop': 'H5'
};

function tr(key) {
  switch (Editor.lang) {
    case 'en':
      return i18nEn[key];
    case 'zh':
      return i18nZh[key];
    default:
      throw new Error('Unknown editor language');
  }
}

function fixedChannelPlatformToName(platform) {
  const enPlatformToNameMap = {
    "fb-instant-games": "Facebook Instant Games",
    "huawei-agc": "HUAWEI AppGallery Connect",
    "alipay": "Alipay Mini Game",
    "qtt-game": "QTT Mini Game",
    "bytedance": "ByteDance Mini Game",
    "jkw-game": "Cocos Play",
    "cocos-play": "Cocos Play",
    "huawei": "Huawei Quick Game",
    "quickgame": "OPPO Mini Game",
    "qgame": "vivo Mini Game",
    "xiaomi": "Xiaomi Quick Game",
    "link-sure": "LinkSure Mini Game",
    "baidugame": "Baidu Mini Game",
    "wechatgame": "WeChat Mini Game",
  };

  const zhPlatformToNameMap = {
    "fb-instant-games": "Facebook Instant Games",
    "huawei-agc": "HUAWEI AppGallery Connect",
    "alipay": "支付宝小游戏",
    "qtt-game": "趣头条小游戏",
    "bytedance": "字节跳动小游戏",
    "jkw-game": "Cocos Play",
    "cocos-play": "Cocos Play",
    "huawei": "华为快游戏",
    "quickgame": "OPPO 小游戏",
    "qgame": "vivo 小游戏",
    "xiaomi": "小米快游戏",
    "link-sure": "连尚小游戏",
    "baidugame": "百度小游戏",
    "wechatgame": "微信小游戏",
  };

  let platformToNameMap = null;
  switch (Editor.lang) {
    case 'en':
      platformToNameMap = enPlatformToNameMap;
      break;
    case 'zh':
      platformToNameMap = zhPlatformToNameMap;
      break;
    default:
      throw new Error('Unknown editor language');
  }

  if (platformToNameMap.hasOwnProperty(platform)) {
    return platformToNameMap[platform];
  }

  return "";
}

function fixedChannelPlatformToStoreId(platform) {
  const platformToStoreIdMap = {
    "fb-instant-games": "160593",
    "huawei-agc": "161221",
    "alipay": "161248",
    "qtt-game": "161252",
    "bytedance": "161251",
    "jkw-game": "161249",
    "cocos-play": "161249",
    "huawei": "160690",
    "quickgame": "160694",
    "qgame": "160691",
    "xiaomi": "160697",
    "link-sure": "161250",
    "baidugame": "160675",
    "wechatgame": "160564",
  };

  if (platformToStoreIdMap.hasOwnProperty(platform)) {
    return platformToStoreIdMap[platform];
  }

  return "";
}

function addUsesPermission(permission, proj) {
  let manifestPath = this.androidPath +`/${proj}/AndroidManifest.xml`;
  if (!fs.existsSync(manifestPath)) return;
  let contents = fs.readFileSync(manifestPath, "utf8");
  if (contents.indexOf(permission) >= 0) return;
  var perStr = `    <uses-permission android:name="android.permission.${permission}"/>`;
  projHelper.insertCodeLine(manifestPath, "uses-permission", perStr);
}

let flagFilePath = __dirname + "/flags";

module.exports = {
  /**
   * 开启服务时会调用此函数，在此函数中要完成的工作：
   *  若服务存在 js 版本的 sdk，则在此处就应该将 sdk 引入到用户的项目中
   * @param {String} projectPath 项目根路径
   * @param {Object} params 服务的参数 ( 若未填写则为 null )
   */
  onServiceEnable(projectPath, params) {
    // 在此处完成 js sdk 的引用
    // Todo...
    if (fs.existsSync(projectPath + '/cocosanalytics.d.ts')) fs.unlinkSync(projectPath + '/cocosanalytics.d.ts');
    utils.copyFile(`${__dirname}/resources/js/cocosanalytics.d.ts`, projectPath + "/cocosanalytics.d.ts");
    if (!fs.existsSync(flagFilePath)) {
      utils.printToCreatorConsole("info", "Cocos Analytics version has changed, please save parameters again!");
      fs.writeFile(flagFilePath, "flag");
    }
  },

  /**
   * 关闭服务时会调用此函数，在此函数中要完成的工作：
   *  将开启服务时安装的 sdk 从用户项目中移除引用并删除
   * @param {String} projectPath 项目根路径
   * @param {Object} params 服务的参数(若未填写则为 null)
   */
  onServiceDisable(projectPath, params) {
    // 在此处完成 js sdk 的移除
    // Todo...
    if (fs.existsSync(`${projectPath}/cocosanalytics.d.ts`)) fs.unlinkSync(`${projectPath}/cocosanalytics.d.ts`);
    if (fs.existsSync(`${projectPath}/temp/analyticsTmp`)) fs.unlinkSync(`${projectPath}/temp/analyticsTmp`);
    utils.removeDir(projectPath + "/packages/cocos-analytics-preview-script");
  },

  /**
   * 当 Creator 构建项目时，且当前服务处于开启状态会调用此函数，在此函数中要完成的工作：
   *   将对应服务的 sdk 集成到项目中
   * @param {Object} options 编译选项
   * @param {Object} params 服务的参数(若未填写则为 null)
   */
  onBuildedProjectEnable(options, params) {
    projHelper = new ProjHelper(options);
    projHelper.Android.addUsesPermission = addUsesPermission;
    projHelper.Android.androidPath = path.join(options.dest, `frameworks/runtime-src/proj.android-studio`);
    if (!this.checkParams(params, options.actualPlatform)) return;

    // 在此处完成构建项目服务 sdk 的集成
    // Todo...
    if (options.actualPlatform === "wechatgame") {
      this.wechat(options);
    } else if (options.actualPlatform === "baidugame") {
      this.baidu(options);
    } else if (
      options.actualPlatform === "jkw-game" ||
      options.actualPlatform === "cocos-play" ||
      options.actualPlatform === "qtt-game" ||
      options.actualPlatform === "huawei" ||
      options.actualPlatform === "quickgame" ||
      options.actualPlatform === "qgame"
    ) {
      this.runtimePlatform(options);
    } else if (options.actualPlatform === "xiaomi") {
      this.xiaomi(options);
    } else if (options.actualPlatform === "qqplay") {
      this.qqplay(options);
    } else if (options.actualPlatform === "alipay") {
      this.alipay(options);
    } else if (options.actualPlatform === "bytedance") {
      this.bytedance(options);
    }
    this.praseHTML(options);
    this.parseJavaScript(options, params);
    this.parseNative(options);

    utils.printToCreatorConsole("log", "The Cocos Analytics service installation is complete!");
  },

  /**
   * 当 Creator 构建项目时，且当前服务处于关闭状态会调用此函数，在此函数中要完成的工作：
   *   将对应服务的 sdk 集成到项目中
   * @param {Object} options 编译选项
   * @param {Object} params 服务的参数(若未填写则为 null)
   */
  onBuildedProjectDisable(options, params) {
    projHelper = new ProjHelper(options);

    // 在此处完成构建项目服务 sdk 的卸载
    // Todo...
    this.uninstallAndroid(options);
    this.uninstallAndroidInstant(options);

    utils.printToCreatorConsole("log", "The Cocos Analytics service uninstallation is complete!");
  },

  // 检查参数是否缺失，返回真表示要跳集成步骤，否则不跳集成步骤。
  checkParams(params, platform) {
    this.fixToGeneralStoreIdIfStoreIdNotExists(params, platform);

    if (!this.checkParamsFixedChannelPlatform(params, platform)) {
      return true;
    }

    if (!this.checkParamsErrorLevel(params, platform)) {
      return false;
    }

    if (this.isGeneralStoreId(params.store_id)) {
      this.warnGeneralStoreId(params, platform);
      return true;
    } else if (params.store_id_platform === "") {
      this.warnUnknownChannel(params);
      return true;
    } else {
      this.checkParamsAndroidIos(params, platform);
      return true;
    }
  },

  fixToGeneralStoreIdIfStoreIdNotExists(params, platform) {
    if (!params.store_id && this.isGeneralStoreIdPlatform(platform)) {
      params.store_id = this.getGeneralStoreId(platform);
    }
  },

  getGeneralStoreId(platform) {
    if (generalStoreIdMap.hasOwnProperty(platform)) {
      return generalStoreIdMap[platform];
    }
    return "";
  },

  isGeneralStoreIdPlatform(platform) {
    if (this.getGeneralStoreId(platform)) {
      return true;
    }
    return false;
  },

  isGeneralStoreId(storeId) {
    for (const platform in generalStoreIdMap) {
      if (generalStoreIdMap.hasOwnProperty(platform) && generalStoreIdMap[platform] === storeId) {
        return true;
      }
    }
    return false;
  },

  checkParamsErrorLevel(params, platform) {
    if (!params) {
      utils.printToCreatorConsole("failed", tr("err_msg_lack_of_params"));
      return false;
    }

    const failedReasons = [];
    if (!params.appid) {
      failedReasons.push(tr("err_msg_missing_appid"));
    }

    if (!params.store_id) {
      failedReasons.push(tr("err_msg_not_channel"));
    }

    if (failedReasons.length !== 0) {
      utils.printToCreatorConsole(
        "failed",
        tr("err_msg_title_integration_failed") + "\n" +
          failedReasons.map((reason, index) => (index + 1) + "." + reason).join("\n") +
          "\n" +
          tr("err_msg_fix_tips")
      );
      return false;
    }
    return true;
  },

  checkParamsAndroidIos(params, platform) {
    let warnMsg = null;
    if (platform === "android" && params.store_id_platform !== "Android") {
      warnMsg = tr("err_msg_not_android_platform");
    } else if (platform === "ios" && params.store_id_platform !== "iOS") {
      warnMsg = tr("err_msg_not_ios_platform");
    }
    if (warnMsg) {
      utils.printToCreatorConsole(
        "warn",
        tr("err_msg_title_warning") +
          "\n" +
          warnMsg +
          "\n" +
          tr("err_msg_keep_use")
      );
      return false;
    }
    return true;
  },

  checkParamsFixedChannelPlatform(params, platform) {
    const platformName = fixedChannelPlatformToName(platform);
    if (platformName === "") {
      return true;
    }

    let warnMsg = null;
    const correctPlatformStoreId = fixedChannelPlatformToStoreId(platform);
    if (params.store_id !== correctPlatformStoreId) {
      warnMsg =
        tr("err_msg_unmatched_fixed_store_id1") +
        platformName +
        tr("err_msg_unmatched_fixed_store_id2") +
        "\n" +
        tr("err_msg_change_fixed_store_id1") +
        correctPlatformStoreId +
        tr("err_msg_change_fixed_store_id2");
        // 新需求：仅提示，不要覆盖用户选择的渠道。
        // params.store_id = correctPlatformStoreId;
    }

    if (warnMsg) {
      utils.printToCreatorConsole(
        "warn",
        tr("err_msg_title_warning") +
          "\n" +
          warnMsg
      );
      return false;
    }

    return true;
  },

  warnGeneralStoreId(params, platform) {
    utils.printToCreatorConsole(
      "warn",
      tr("err_msg_title_warning") +
        "\n" +
        tr("err_msg_general_store_id1") +
        platform +
        tr("err_msg_general_store_id2") +
        params.store_id +
        tr("err_msg_general_store_id3")
    );
  },

  warnUnknownChannel(params) {
    utils.printToCreatorConsole(
      "warn",
      tr("err_msg_title_warning") +
        "\n" +
        tr("err_msg_unknown_channel1") +
        params.store_id +
        tr("err_msg_unknown_channel2")
    );
  },

  wechat(options) {
    var list = [];
    var destName = 'ccAnalytics.min.js';
    list.push({
      src: __dirname + "/resources/js/" + analyticsFileName,
      dst: path.join(options.dest, destName)
    });
    utils.copyServicePackages(list);
    var requireCode = `require("${destName}");`;
    var gameJSPath = path.join(options.dest, "game.js");
    projHelper.insertCodeLine(gameJSPath, /require\('(.*)main(.*)'\);/, requireCode, true);
  },
  baidu(options) {
    var list = [];
    list.push({
      src: __dirname + "/resources/js/" + analyticsFileName,
      dst: path.join(options.dest, analyticsFileName)
    });
    utils.copyServicePackages(list);
    var requireCode = `    require("${analyticsFileName}");`;
    var gameJSPath = path.join(options.dest, "game.js");
    projHelper.insertCodeLine(gameJSPath, /require\('(.*)main(.*)'\);/, requireCode, true);
  },
  alipay(options) {
    var list = [];
    list.push({
      src: __dirname + "/resources/js/" + analyticsFileName,
      dst: path.join(options.dest, "src/" + analyticsFileName)
    });
    utils.copyServicePackages(list);
    var requireCode = `require("src/${analyticsFileName}");`;
    var gameJSPath = path.join(options.dest, "game.js");
    projHelper.insertCodeLine(gameJSPath, /window\.boot\(\);/, requireCode, true);
  },
  bytedance(options) {
    var list = [];
    list.push({
      src: __dirname + "/resources/js/" + analyticsFileName,
      dst: path.join(options.dest, analyticsFileName)
    });
    utils.copyServicePackages(list);
    var requireCode = `    require("${analyticsFileName}");`;
    var gameJSPath = path.join(options.dest, "game.js");
    projHelper.insertCodeLine(gameJSPath, /require\('(.*)main(.*)'\);/, requireCode, true);
  },
  runtimePlatform(options) {
    var list = [];
    list.push({
      src: __dirname + "/resources/js/" + analyticsFileName,
      dst: path.join(options.dest, "src/" + analyticsFileName)
    });
    utils.copyServicePackages(list);
    var requireCode = `        require("src/${analyticsFileName}");`;
    var gameJSPath = path.join(options.dest, "main.js");
    projHelper.insertCodeLine(gameJSPath, /require\('src\/cocos2d-runtime.js'\);/, requireCode, false);
  },
  xiaomi(options) {
    var list = [];
    list.push({
      src: __dirname + "/resources/js/" + analyticsFileName,
      dst: path.join(options.dest, "src/" + analyticsFileName)
    });
    utils.copyServicePackages(list);
    var requireCode = `require('src/${analyticsFileName}');`;
    var gameJSPath = path.join(options.dest, "main.js");
    projHelper.insertCodeLine(gameJSPath, /window\.boot\(\);/, requireCode, true);
  },
  qqplay(options) {
    var list = [];
    list.push({
      src: __dirname + "/resources/js/" + analyticsFileName,
      dst: path.join(options.dest, "src/" + analyticsFileName)
    });
    if (options.md5Cache) {
      var fileName = crypto.createHash("md5").update(fs.readFileSync(list[0].src)).digest('hex').substring(0, 5);
      analyticsFileName = analyticsFileName.replace("js", `${fileName}.js`);
    }
    utils.copyServicePackages(list);
    var requireCode = `    BK.Script.loadlib('GameRes://src/${analyticsFileName}');`;
    var gameJSPath = path.join(options.dest, "main.js");
    projHelper.insertCodeLine(gameJSPath, /'GameRes:\/\/libs\/qqplay-downloader.js'/, requireCode, false);
  },
  // 处理Web平台（Web-Mobile / Web-Desktop / Facebook Instant Games）的index.html文件
  praseHTML(options) {
    const analyticsHtml = `
<script src="https://download.cocos.com/CocosAnalytics/sdk/${analyticsFileName}" charset="utf-8"></script>
`;
    projHelper.insertScriptToIndexHTML(analyticsHtml);
  },
  // 处理index.js文件
  parseJavaScript(options, params) {
    let analysticsCode = `
// Begin Cocos Analytics
(function () {
  if((typeof window.location.protocol)==='undefined'){
    window.location.protocol='';
  }
  if ((typeof cocosAnalytics) !== 'undefined'){
    var initArgs = {
      appID: '${sanitizeUserParam(params.appid)}',
      storeID: '${sanitizeUserParam(params.store_id)}',
      engine: 'cocos',
      callNumber: ''
    };
    if (!initArgs.appID || !initArgs.storeID) {
      console.error('请在编辑器设置好 Cocos Analytics 的 appID，如果在Android或者iOS下发布，请选择好对应的渠道');
      return;
    }
    var cocosAnalyticsID1 = cocosAnalytics.init(initArgs);
    let _global = globalThis || window;
    _global.cocosAnalyticsID1 = _global.cocosAnalyticsID1 || cocosAnalyticsID1;
  }
})();
// End Cocos Analytics
    `;
    if (
      options.actualPlatform === "android" ||
      options.actualPlatform === "ios" ||
      options.actualPlatform === "android-instant" ||
      options.actualPlatform === "huawei-agc"
    ) {
      projHelper.insertRequireWithMainJS("src/jsb-cocosanalytics.js");
    }
    if (options.actualPlatform === 'alipay') {
      projHelper.appendCodeLine(path.join(options.dest, "game.js"), analysticsCode);
    } else {
      projHelper.insertToMainJS(analysticsCode);
    }
  },
  // 原生工程处理入口
  parseNative(options) {
    let projectFilePath = path.join(options.dest, "project.json");
    if (fs.existsSync(projectFilePath))
      utils.parseProjectJson(projectFilePath, "org.cocos2dx.javascript.service.ServiceAnalytics", true);
    if (options.actualPlatform === "ios") {
      this.copyFiles(options);
      this.ios(options);
    } else if (options.actualPlatform === "android" || options.actualPlatform === "huawei-agc") {
      this.copyFiles(options);
      this.android(options);
    } else if (options.actualPlatform === "android-instant") {
      //2.4.7 gradle升级,android-instant构建位置不在是game,而是instantapp
      let versionArray = ccServices.getCreatorVersion().split(".");
      let numVersion = Number(versionArray[0])*10000+Number(versionArray[1])*100+Number(versionArray[2])
      if(numVersion>=20407){
        // utils.printToCreatorConsole("log", "version>=2.4.7");
        this.copyFiles(options,"instantapp");
        this.androidInstant(options,"instantapp");
      }else{
        // utils.printToCreatorConsole("log", "version<2.4.7");
        this.copyFiles(options,"game");
        this.androidInstant(options,"game");
      }
    }
  },
  // Native 构建平台（iOS、Android、Android Instant）
  copyFiles(options,instant) {
    var runtimePath = path.join(options.dest, "frameworks/runtime-src");
    var list = [];
    list.push({
      src: __dirname + "/resources/js/jsb-cocosanalytics.js",
      dst: path.join(options.dest, "src/jsb-cocosanalytics.js")
    });
    if (options.actualPlatform === "ios") {
      list.push({
        src: __dirname + "/resources/src/ios/ServiceAnalytics.h",
        dst: path.join(runtimePath, "proj.ios_mac/ios/service/ServiceAnalytics.h")
      });
      list.push({
        src: __dirname + "/resources/src/ios/ServiceAnalytics.m",
        dst: path.join(runtimePath, "proj.ios_mac/ios/service/ServiceAnalytics.m")
      });
      list.push({
        src: __dirname + "/resources/sdk/ios/CocosAnalytics.framework",
        dst: path.join(runtimePath, "proj.ios_mac/ios/CocosAnalytics.framework")
      });
    } else if (options.actualPlatform === "android" || options.actualPlatform === "huawei-agc") {
      list.push({
        src: __dirname + "/resources/src/android/ServiceAnalytics.java",
        dst: path.join(runtimePath, "proj.android-studio/app/src/org/cocos2dx/javascript/service/ServiceAnalytics.java")
      });
      list.push({
        src: __dirname + "/resources/sdk/android/libcocosanalytics.aar",
        dst: path.join(runtimePath, "proj.android-studio/app/libs/libcocosanalytics.aar")
      });
    } else if (options.actualPlatform === "android-instant") {
      list.push({
        src: __dirname + "/resources/src/android/ServiceAnalytics.java",
        dst: path.join(runtimePath, `proj.android-studio/${instant}/src/org/cocos2dx/javascript/service/ServiceAnalytics.java`)
      });
      list.push({
        src: __dirname + "/resources/sdk/android/libcocosanalytics.aar",
        dst: path.join(runtimePath, `proj.android-studio/${instant}/libs/libcocosanalytics.aar`)
      });
    }
    utils.copyServicePackages(list);
  },
  ios(options) {
    let targetName = `${options.projectName}-mobile`;
    // TODO: 将下面的代码统一放到 projHelper.iOS 对象中
    let frameworkPath = "ios/CocosAnalytics.framework";
    let targetIOS = projHelper.iOS._searchTarget(targetName);
    if (targetIOS) {
      // TODO: 调整原始模板工程配置
      // 如果模板工程已经配置好的话，以下代码可以不需要。
      // Detail: https://github.com/alunny/node-xcode/issues/78
      let existsEmbedFrameworks = projHelper.iOS.project.buildPhaseObject('PBXCopyFilesBuildPhase', 'Embed Frameworks');
      if (!existsEmbedFrameworks) {
        projHelper.iOS.project.addBuildPhase([], 'PBXCopyFilesBuildPhase', 'Embed Frameworks', null, 'frameworks');
      }
      projHelper.iOS.project.updateBuildProperty('LD_RUNPATH_SEARCH_PATHS', '"@executable_path/Frameworks"', 'Debug');
      projHelper.iOS.project.updateBuildProperty('LD_RUNPATH_SEARCH_PATHS', '"@executable_path/Frameworks"','Release');
      projHelper.iOS.project.addFramework(frameworkPath, {
        customFramework: true,
        target: targetIOS,
        embed: false,
        sign: false,
      });
    }
    utils.printLog(`add framework "${frameworkPath} to iOS project`);
    projHelper.iOS.savePBXProjectConfig();
    projHelper.iOS.addHeaderFileToProject("ServiceAnalytics.h", "service", targetName);
    projHelper.iOS.addSourceFileToProject("ServiceAnalytics.m", "service", targetName);
    projHelper.iOS.addToHeaderSearchPaths("ios/CocosAnalytics.framework/Headers")
    // projHelper.iOS.printPBXProjectConfig();
  },
  android(options) {
    projHelper.Android.addUsesPermission("INTERNET","app");
    projHelper.Android.addUsesPermission("ACCESS_FINE_LOCATION","app");
    projHelper.Android.addUsesPermission("ACCESS_NETWORK_STATE","app");

    var proguradRules = `
# Proguard Cocos Analytics for release
-keep class com.cocos.analytics.** { *; }
-dontwarn com.cocos.analytics.**
`;
    var proguradPath = options.dest + "/frameworks/runtime-src/proj.android-studio/app/proguard-rules.pro";
    if (!fs.existsSync(proguradPath)) return;
    let contents = fs.readFileSync(proguradPath, "utf8");
    if (contents.indexOf("Analytics") >= 0) return;
    projHelper.appendCodeLine(proguradPath, proguradRules);
  },
  androidInstant(options,proj) {
    projHelper.Android.addUsesPermission("INTERNET", proj);
    projHelper.Android.addUsesPermission("ACCESS_FINE_LOCATION", proj);
    projHelper.Android.addUsesPermission("ACCESS_NETWORK_STATE", proj);

    var proguradRules = `
# Proguard Cocos Analytics for release
-keep class com.cocos.analytics.** { *; }
-dontwarn com.cocos.analytics.**
`;
    var proguradPath = options.dest + `/frameworks/runtime-src/proj.android-studio/${proj}/proguard-rules.pro`;
    if (!fs.existsSync(proguradPath)) return;
    let contents = fs.readFileSync(proguradPath, "utf8");
    if (contents.indexOf("Analytics") >= 0) return;
    projHelper.appendCodeLine(proguradPath, proguradRules);
  },
  uninstallAndroid(options) {
    var runtimePath = path.join(options.dest, "frameworks/runtime-src");
    var list = [];
    list.push({
      src: __dirname + "/resources/src/android/ServiceAnalytics.java",
      dst: path.join(runtimePath, "proj.android-studio/app/src/org/cocos2dx/javascript/service/ServiceAnalytics.java")
    });
    list.push({
      src: __dirname + "/resources/sdk/android/libcocosanalytics.aar",
      dst: path.join(runtimePath, "proj.android-studio/app/libs/libcocosanalytics.aar")
    });
    utils.deleteServicePackages(list);
  },
  uninstallAndroidInstant(options) {
    var runtimePath = path.join(options.dest, "frameworks/runtime-src");
    var list = [];
    let proj = 'game';
    let versionArray = ccServices.getCreatorVersion().split(".");
    let numVersion = Number(versionArray[0])*10000+Number(versionArray[1])*100+Number(versionArray[2])
    if(numVersion>=20407){
      proj = 'instantapp';
    }
    list.push({
      src: __dirname + "/resources/src/android/ServiceAnalytics.java",
      dst: path.join(runtimePath, `proj.android-studio/${proj}/src/org/cocos2dx/javascript/service/ServiceAnalytics.java`)
    });
    list.push({
      src: __dirname + "/resources/sdk/android/libcocosanalytics.aar",
      dst: path.join(runtimePath, `proj.android-studio/${proj}/libs/libcocosanalytics.aar`)
    });
    utils.deleteServicePackages(list);
  }
};

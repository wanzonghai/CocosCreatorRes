module.exports = {
    title: 'netease-yidun-encrypt'
}